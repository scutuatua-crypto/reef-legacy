#!/usr/bin/env node

import * as fsPromises from 'node:fs/promises';

const scriptURL = new URL(import.meta.url);
const fileHandle = await fsPromises.open(scriptURL);
const readableStream = fileHandle.readableWebStream();
const reader = readableStream.getReader({ mode: "byob" });
const arrayBuffer = new ArrayBuffer(3);
const view = new Uint8Array(arrayBuffer, 2, 1);
const result = await reader.read(view);
